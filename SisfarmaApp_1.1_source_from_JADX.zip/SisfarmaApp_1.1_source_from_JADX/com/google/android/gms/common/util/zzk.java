package com.google.android.gms.common.util;

public interface zzk<F, T> {
    T apply(F f);
}
