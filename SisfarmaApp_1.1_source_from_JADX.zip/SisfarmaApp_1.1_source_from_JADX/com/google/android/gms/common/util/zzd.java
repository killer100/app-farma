package com.google.android.gms.common.util;

public interface zzd {
    long currentTimeMillis();

    long elapsedRealtime();

    long nanoTime();
}
