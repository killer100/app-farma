package com.google.android.gms.common.util;

public interface zzr<T> {
    boolean apply(T t);
}
