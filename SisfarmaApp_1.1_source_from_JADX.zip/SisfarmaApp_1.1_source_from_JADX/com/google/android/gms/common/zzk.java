package com.google.android.gms.common;

final class zzk {
    static final zzh[] zzflf = new zzh[]{new zzl(zzh.zzfx("0\u0004C0\u0003+ \u0003\u0002\u0001\u0002\u0002\t\u0000ÂàFdJ00")), new zzm(zzh.zzfx("0\u0004¨0\u0003 \u0003\u0002\u0001\u0002\u0002\t\u0000Õ¸l}ÓNõ0"))};
}
