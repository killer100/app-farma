package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.IInterface;
import com.google.android.gms.common.api.Api.zzg;

public final class zzbz<T extends IInterface> extends zzab<T> {
    public static zzg<T> zzals() {
        throw new NoSuchMethodError();
    }

    protected final T zzd(IBinder iBinder) {
        throw new NoSuchMethodError();
    }

    protected final String zzhi() {
        throw new NoSuchMethodError();
    }

    protected final String zzhj() {
        throw new NoSuchMethodError();
    }
}
