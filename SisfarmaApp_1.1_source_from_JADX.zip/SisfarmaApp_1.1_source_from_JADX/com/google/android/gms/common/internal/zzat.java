package com.google.android.gms.common.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;

public interface zzat extends IInterface {
    IObjectWrapper zzaga() throws RemoteException;

    int zzagb() throws RemoteException;
}
