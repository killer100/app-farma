package com.google.android.gms.common.internal;

import android.os.Bundle;

public interface zzaf {
    boolean isConnected();

    Bundle zzafi();
}
