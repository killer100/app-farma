package com.google.android.gms.common.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.common.ConnectionResult;

public interface zzj {
    void zzf(@NonNull ConnectionResult connectionResult);
}
