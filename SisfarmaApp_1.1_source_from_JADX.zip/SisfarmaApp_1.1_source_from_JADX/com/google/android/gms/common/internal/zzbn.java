package com.google.android.gms.common.internal;

import com.google.android.gms.common.api.Result;

final class zzbn implements zzbo<R, Void> {
    zzbn() {
    }

    public final /* bridge */ /* synthetic */ Object zzb(Result result) {
        return null;
    }
}
