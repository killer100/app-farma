package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.support.annotation.Nullable;

public interface zzf {
    void onConnected(@Nullable Bundle bundle);

    void onConnectionSuspended(int i);
}
