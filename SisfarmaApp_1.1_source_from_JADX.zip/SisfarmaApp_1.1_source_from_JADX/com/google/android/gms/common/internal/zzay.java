package com.google.android.gms.common.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzay extends IInterface {
    void zza(zzaw com_google_android_gms_common_internal_zzaw, zzz com_google_android_gms_common_internal_zzz) throws RemoteException;
}
