package com.google.android.gms.common.internal;

import com.google.android.gms.common.api.Result;

public interface zzbo<R extends Result, T> {
    T zzb(R r);
}
