package com.google.android.gms.common.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.zzn;
import com.google.android.gms.dynamic.IObjectWrapper;

public interface zzba extends IInterface {
    boolean zza(zzn com_google_android_gms_common_zzn, IObjectWrapper iObjectWrapper) throws RemoteException;
}
