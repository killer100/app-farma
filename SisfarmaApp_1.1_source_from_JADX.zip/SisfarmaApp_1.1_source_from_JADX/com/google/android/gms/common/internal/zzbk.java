package com.google.android.gms.common.internal;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Status;

final class zzbk implements zzbp {
    zzbk() {
    }

    public final ApiException zzz(Status status) {
        return zzb.zzy(status);
    }
}
