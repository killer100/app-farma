package com.google.android.gms.common.internal;

import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Status;

public interface zzbp {
    ApiException zzz(Status status);
}
