package com.google.android.gms.common.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;

public interface zzbd extends IInterface {
    IObjectWrapper zza(IObjectWrapper iObjectWrapper, zzbv com_google_android_gms_common_internal_zzbv) throws RemoteException;
}
