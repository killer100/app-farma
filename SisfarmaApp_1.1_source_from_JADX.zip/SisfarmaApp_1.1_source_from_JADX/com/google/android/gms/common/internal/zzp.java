package com.google.android.gms.common.internal;

public interface zzp {
    void zzajf();
}
