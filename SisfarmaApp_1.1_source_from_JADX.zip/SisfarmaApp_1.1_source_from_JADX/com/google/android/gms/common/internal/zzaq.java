package com.google.android.gms.common.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzaq extends IInterface {
    void cancel() throws RemoteException;
}
