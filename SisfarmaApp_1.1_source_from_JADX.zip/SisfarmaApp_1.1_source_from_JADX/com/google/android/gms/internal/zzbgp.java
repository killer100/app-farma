package com.google.android.gms.internal;

public interface zzbgp<I, O> {
    I convertBack(O o);
}
