package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzbge extends IInterface {
    void zza(zzbgc com_google_android_gms_internal_zzbgc) throws RemoteException;
}
