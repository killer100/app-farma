package com.google.android.gms.internal;

import java.util.List;

public final class zzfim extends RuntimeException {
    private final List<String> zzpko = null;

    public zzfim(zzfhe com_google_android_gms_internal_zzfhe) {
        super("Message was missing required fields.  (Lite runtime could not determine which fields were missing).");
    }

    public final zzfge zzczt() {
        return new zzfge(getMessage());
    }
}
