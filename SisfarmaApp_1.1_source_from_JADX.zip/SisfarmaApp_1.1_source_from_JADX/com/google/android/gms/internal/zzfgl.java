package com.google.android.gms.internal;

import java.util.List;

public interface zzfgl extends List {
    List<?> zzcyl();
}
