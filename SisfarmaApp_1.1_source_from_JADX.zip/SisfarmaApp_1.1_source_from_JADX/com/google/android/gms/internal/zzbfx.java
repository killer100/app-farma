package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.GoogleApiClient;

final class zzbfx extends zzbga {
    zzbfx(zzbfw com_google_android_gms_internal_zzbfw, GoogleApiClient googleApiClient) {
        super(googleApiClient);
    }

    protected final /* synthetic */ void zza(zzb com_google_android_gms_common_api_Api_zzb) throws RemoteException {
        ((zzbge) ((zzbgb) com_google_android_gms_common_api_Api_zzb).zzakn()).zza(new zzbfy(this));
    }
}
