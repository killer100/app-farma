package com.google.android.gms.internal;

final /* synthetic */ class zzfgw {
    static final /* synthetic */ int[] zzpgo = new int[zzfiy.values().length];

    static {
        try {
            zzpgo[zzfiy.MESSAGE.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            zzpgo[zzfiy.ENUM.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            zzpgo[zzfiy.GROUP.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
    }
}
