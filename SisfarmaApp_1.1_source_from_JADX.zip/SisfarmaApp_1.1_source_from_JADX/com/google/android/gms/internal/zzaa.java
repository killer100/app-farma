package com.google.android.gms.internal;

public interface zzaa {
    void zza(zzad com_google_android_gms_internal_zzad) throws zzad;

    int zzb();

    int zzc();
}
