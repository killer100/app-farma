package com.google.android.gms.internal;

public final class zzq extends zzo {
    public zzq(Throwable th) {
        super(th);
    }
}
