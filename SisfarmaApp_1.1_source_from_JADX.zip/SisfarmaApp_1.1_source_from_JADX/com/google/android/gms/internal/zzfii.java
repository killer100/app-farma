package com.google.android.gms.internal;

final class zzfii implements zzfij {
    private /* synthetic */ zzfes zzpkk;

    zzfii(zzfes com_google_android_gms_internal_zzfes) {
        this.zzpkk = com_google_android_gms_internal_zzfes;
    }

    public final int size() {
        return this.zzpkk.size();
    }

    public final byte zzkn(int i) {
        return this.zzpkk.zzkn(i);
    }
}
