package com.google.android.gms.internal;

public final class zzcus {
    private static long zzjxo = 0;
}
