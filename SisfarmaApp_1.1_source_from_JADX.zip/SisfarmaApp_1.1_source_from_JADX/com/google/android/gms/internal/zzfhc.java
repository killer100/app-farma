package com.google.android.gms.internal;

interface zzfhc {
    int zzcyv();

    boolean zzcyw();

    zzfhe zzcyx();

    boolean zzcyy();
}
