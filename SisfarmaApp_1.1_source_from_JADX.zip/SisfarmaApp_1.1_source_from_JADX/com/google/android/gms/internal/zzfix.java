package com.google.android.gms.internal;

final /* synthetic */ class zzfix {
    static final /* synthetic */ int[] zzpgo = new int[zzfiy.values().length];

    static {
        try {
            zzpgo[zzfiy.DOUBLE.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            zzpgo[zzfiy.FLOAT.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            zzpgo[zzfiy.INT64.ordinal()] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            zzpgo[zzfiy.UINT64.ordinal()] = 4;
        } catch (NoSuchFieldError e4) {
        }
        try {
            zzpgo[zzfiy.INT32.ordinal()] = 5;
        } catch (NoSuchFieldError e5) {
        }
        try {
            zzpgo[zzfiy.FIXED64.ordinal()] = 6;
        } catch (NoSuchFieldError e6) {
        }
        try {
            zzpgo[zzfiy.FIXED32.ordinal()] = 7;
        } catch (NoSuchFieldError e7) {
        }
        try {
            zzpgo[zzfiy.BOOL.ordinal()] = 8;
        } catch (NoSuchFieldError e8) {
        }
        try {
            zzpgo[zzfiy.BYTES.ordinal()] = 9;
        } catch (NoSuchFieldError e9) {
        }
        try {
            zzpgo[zzfiy.UINT32.ordinal()] = 10;
        } catch (NoSuchFieldError e10) {
        }
        try {
            zzpgo[zzfiy.SFIXED32.ordinal()] = 11;
        } catch (NoSuchFieldError e11) {
        }
        try {
            zzpgo[zzfiy.SFIXED64.ordinal()] = 12;
        } catch (NoSuchFieldError e12) {
        }
        try {
            zzpgo[zzfiy.SINT32.ordinal()] = 13;
        } catch (NoSuchFieldError e13) {
        }
        try {
            zzpgo[zzfiy.SINT64.ordinal()] = 14;
        } catch (NoSuchFieldError e14) {
        }
        try {
            zzpgo[zzfiy.STRING.ordinal()] = 15;
        } catch (NoSuchFieldError e15) {
        }
        try {
            zzpgo[zzfiy.GROUP.ordinal()] = 16;
        } catch (NoSuchFieldError e16) {
        }
        try {
            zzpgo[zzfiy.MESSAGE.ordinal()] = 17;
        } catch (NoSuchFieldError e17) {
        }
        try {
            zzpgo[zzfiy.ENUM.ordinal()] = 18;
        } catch (NoSuchFieldError e18) {
        }
    }
}
