package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzfo extends IInterface {
    String getId() throws RemoteException;

    boolean zzb(boolean z) throws RemoteException;

    boolean zzbp() throws RemoteException;
}
