package com.google.android.gms.internal;

final class zzfgr implements zzfhd {
    zzfgr() {
    }

    public final boolean zzi(Class<?> cls) {
        return false;
    }

    public final zzfhc zzj(Class<?> cls) {
        throw new IllegalStateException("This should never be called.");
    }
}
