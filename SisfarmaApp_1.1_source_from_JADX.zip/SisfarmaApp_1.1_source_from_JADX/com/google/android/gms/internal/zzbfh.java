package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;

final class zzbfh extends Drawable {
    private static final zzbfh zzfya = new zzbfh();
    private static final zzbfi zzfyb = new zzbfi();

    private zzbfh() {
    }

    public final void draw(Canvas canvas) {
    }

    public final ConstantState getConstantState() {
        return zzfyb;
    }

    public final int getOpacity() {
        return -2;
    }

    public final void setAlpha(int i) {
    }

    public final void setColorFilter(ColorFilter colorFilter) {
    }
}
