package com.google.android.gms.internal;

import java.nio.ByteBuffer;

final class zzfhi<T> implements zzfhv<T> {
    private final ByteBuffer buffer;

    static <T> zzfhi<T> zza(Class<T> cls, zzfhc com_google_android_gms_internal_zzfhc, zzfgm com_google_android_gms_internal_zzfgm, zzfin<?, ?> com_google_android_gms_internal_zzfin___, zzffn<?> com_google_android_gms_internal_zzffn_, zzfgz com_google_android_gms_internal_zzfgz) {
        if (com_google_android_gms_internal_zzfhc instanceof zzfhp) {
            throw new NoSuchMethodError();
        }
        zzfig com_google_android_gms_internal_zzfig = (zzfig) com_google_android_gms_internal_zzfhc;
        throw new NoSuchMethodError();
    }

    static <T> zzfhi<T> zzb(Class<T> cls, zzfhc com_google_android_gms_internal_zzfhc, zzfgm com_google_android_gms_internal_zzfgm, zzfin<?, ?> com_google_android_gms_internal_zzfin___, zzffn<?> com_google_android_gms_internal_zzffn_, zzfgz com_google_android_gms_internal_zzfgz) {
        if (com_google_android_gms_internal_zzfhc instanceof zzfhp) {
            throw new NoSuchMethodError();
        }
        zzfig com_google_android_gms_internal_zzfig = (zzfig) com_google_android_gms_internal_zzfhc;
        throw new NoSuchMethodError();
    }

    public final void zza(T t, zzfji com_google_android_gms_internal_zzfji) {
        throw new NoSuchMethodError();
    }

    public final int zzcp(T t) {
        throw new NoSuchMethodError();
    }
}
