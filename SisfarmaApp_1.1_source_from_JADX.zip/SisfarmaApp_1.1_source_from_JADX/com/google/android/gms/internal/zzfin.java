package com.google.android.gms.internal;

abstract class zzfin<T, B> {
    zzfin() {
    }

    abstract void zzb(T t, zzfji com_google_android_gms_internal_zzfji);

    abstract T zzcq(Object obj);

    abstract int zzcr(T t);
}
