package com.google.android.gms.internal;

class zzfgm {
    private static final zzfgm zzpib = new zzfgo();
    private static final zzfgm zzpic = new zzfgp();

    private zzfgm() {
    }

    static zzfgm zzcym() {
        return zzpib;
    }

    static zzfgm zzcyn() {
        return zzpic;
    }
}
