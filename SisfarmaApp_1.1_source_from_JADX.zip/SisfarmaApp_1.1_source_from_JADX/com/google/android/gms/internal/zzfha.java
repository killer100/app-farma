package com.google.android.gms.internal;

final class zzfha implements zzfgz {
    zzfha() {
    }
}
