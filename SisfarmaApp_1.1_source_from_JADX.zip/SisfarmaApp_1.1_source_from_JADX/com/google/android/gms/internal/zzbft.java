package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.zza;
import com.google.android.gms.common.api.Api.zzf;

public final class zzbft {
    public static final Api<NoOptions> API = new Api("Common.API", zzebg, zzebf);
    public static final zzf<zzbgb> zzebf = new zzf();
    private static final zza<zzbgb, NoOptions> zzebg = new zzbfu();
    public static final zzbfv zzgbv = new zzbfw();
}
