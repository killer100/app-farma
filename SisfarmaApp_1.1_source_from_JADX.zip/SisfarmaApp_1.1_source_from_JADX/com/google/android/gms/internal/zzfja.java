package com.google.android.gms.internal;

enum zzfja extends zzfiy {
    zzfja(String str, int i, zzfjd com_google_android_gms_internal_zzfjd, int i2) {
        super(str, 9, com_google_android_gms_internal_zzfjd, 3);
    }
}
