package com.google.android.gms.internal;

final class zzbfb extends zzbey<Integer> {
    zzbfb(String str, Integer num) {
        super(str, num);
    }
}
