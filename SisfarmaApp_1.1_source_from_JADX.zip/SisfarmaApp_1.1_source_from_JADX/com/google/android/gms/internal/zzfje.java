package com.google.android.gms.internal;

import java.io.IOException;

enum zzfje {
    LOOSE,
    STRICT,
    LAZY;

    abstract Object zza(zzffb com_google_android_gms_internal_zzffb) throws IOException;
}
