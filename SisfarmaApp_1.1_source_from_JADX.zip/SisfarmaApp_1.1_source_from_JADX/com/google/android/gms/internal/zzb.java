package com.google.android.gms.internal;

public interface zzb {
    void initialize();

    zzc zza(String str);

    void zza(String str, zzc com_google_android_gms_internal_zzc);
}
