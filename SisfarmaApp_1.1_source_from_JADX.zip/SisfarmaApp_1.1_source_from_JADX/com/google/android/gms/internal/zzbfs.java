package com.google.android.gms.internal;

import android.os.RemoteException;

public class zzbfs extends zzbgd {
    public void zzci(int i) throws RemoteException {
    }
}
