package com.google.android.gms.internal;

import com.google.android.gms.internal.zzffu.zzg;

final /* synthetic */ class zzffx {
    static final /* synthetic */ int[] zzbbi = new int[zzg.m3x126d66cb().length];

    static {
        try {
            zzbbi[zzg.zzphi - 1] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            zzbbi[zzg.zzphc - 1] = 2;
        } catch (NoSuchFieldError e2) {
        }
        try {
            zzbbi[zzg.zzphh - 1] = 3;
        } catch (NoSuchFieldError e3) {
        }
        try {
            zzbbi[zzg.zzphj - 1] = 4;
        } catch (NoSuchFieldError e4) {
        }
        try {
            zzbbi[zzg.zzphd - 1] = 5;
        } catch (NoSuchFieldError e5) {
        }
        try {
            zzbbi[zzg.zzphg - 1] = 6;
        } catch (NoSuchFieldError e6) {
        }
        try {
            zzbbi[zzg.zzphk - 1] = 7;
        } catch (NoSuchFieldError e7) {
        }
        try {
            zzbbi[zzg.zzphl - 1] = 8;
        } catch (NoSuchFieldError e8) {
        }
        try {
            zzbbi[zzg.zzphe - 1] = 9;
        } catch (NoSuchFieldError e9) {
        }
        try {
            zzbbi[zzg.zzphf - 1] = 10;
        } catch (NoSuchFieldError e10) {
        }
    }
}
