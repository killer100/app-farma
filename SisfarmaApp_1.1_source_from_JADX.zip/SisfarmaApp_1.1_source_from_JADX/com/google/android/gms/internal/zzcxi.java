package com.google.android.gms.internal;

import android.os.RemoteException;

public class zzcxi extends zzcxk {
    public void zzb(zzcxq com_google_android_gms_internal_zzcxq) throws RemoteException {
    }
}
