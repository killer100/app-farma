package com.google.android.gms.internal;

interface zzt {
    void zza(zzr<?> com_google_android_gms_internal_zzr_);

    void zza(zzr<?> com_google_android_gms_internal_zzr_, zzw<?> com_google_android_gms_internal_zzw_);
}
