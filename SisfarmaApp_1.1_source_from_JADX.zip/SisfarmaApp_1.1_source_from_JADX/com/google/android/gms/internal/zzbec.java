package com.google.android.gms.internal;

public interface zzbec {
    byte[] zzafv();
}
