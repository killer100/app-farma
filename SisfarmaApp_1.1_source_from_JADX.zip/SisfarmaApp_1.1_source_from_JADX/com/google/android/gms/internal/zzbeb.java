package com.google.android.gms.internal;

public interface zzbeb {
    boolean zzg(String str, int i);
}
