package com.google.android.gms.internal;

final /* synthetic */ class zzfgs {
    static final /* synthetic */ int[] zzpih = new int[zzfgu.values().length];

    static {
        try {
            zzpih[zzfgu.TABLE.ordinal()] = 1;
        } catch (NoSuchFieldError e) {
        }
        try {
            zzpih[zzfgu.LOOKUP.ordinal()] = 2;
        } catch (NoSuchFieldError e2) {
        }
    }
}
