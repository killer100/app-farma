package com.google.android.gms.internal;

public interface zzfgc extends zzfgd<Integer> {
    int getInt(int i);

    zzfgc zzlu(int i);

    void zzlv(int i);
}
