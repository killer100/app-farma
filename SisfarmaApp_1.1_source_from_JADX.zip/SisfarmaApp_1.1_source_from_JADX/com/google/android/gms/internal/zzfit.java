package com.google.android.gms.internal;

abstract class zzfit {
    zzfit() {
    }

    abstract int zzb(int i, byte[] bArr, int i2, int i3);

    abstract int zzb(CharSequence charSequence, byte[] bArr, int i, int i2);
}
