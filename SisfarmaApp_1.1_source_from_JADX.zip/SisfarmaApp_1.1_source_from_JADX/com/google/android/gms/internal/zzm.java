package com.google.android.gms.internal;

public interface zzm {
    zzp zzc(zzr<?> com_google_android_gms_internal_zzr_) throws zzad;
}
