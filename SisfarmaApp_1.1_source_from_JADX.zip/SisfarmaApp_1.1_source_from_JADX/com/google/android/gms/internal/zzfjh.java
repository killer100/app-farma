package com.google.android.gms.internal;

import java.io.IOException;

enum zzfjh extends zzfje {
    zzfjh(String str, int i) {
        super(str, 2);
    }

    final Object zza(zzffb com_google_android_gms_internal_zzffb) throws IOException {
        return com_google_android_gms_internal_zzffb.zzcwb();
    }
}
