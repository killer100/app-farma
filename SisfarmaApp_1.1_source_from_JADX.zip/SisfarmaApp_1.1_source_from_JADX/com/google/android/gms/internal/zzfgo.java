package com.google.android.gms.internal;

import java.util.Collections;

final class zzfgo extends zzfgm {
    private static final Class<?> zzpid = Collections.unmodifiableList(Collections.emptyList()).getClass();

    private zzfgo() {
        super();
    }
}
