package com.google.android.gms.internal;

import java.util.ArrayList;
import java.util.Collection;

public final class zzcaw {
    private final Collection<zzcaq> zzbhd = new ArrayList();
    private final Collection<zzcav> zzbhe = new ArrayList();
    private final Collection<zzcav> zzbhf = new ArrayList();

    public final void zza(zzcaq com_google_android_gms_internal_zzcaq) {
        this.zzbhd.add(com_google_android_gms_internal_zzcaq);
    }
}
