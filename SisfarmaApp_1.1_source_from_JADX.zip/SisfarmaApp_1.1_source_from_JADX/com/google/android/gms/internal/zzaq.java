package com.google.android.gms.internal;

import java.io.IOException;
import java.util.Map;
import org.apache.http.HttpResponse;

@Deprecated
public interface zzaq {
    HttpResponse zzb(zzr<?> com_google_android_gms_internal_zzr_, Map<String, String> map) throws IOException, zza;
}
