package com.google.android.gms.internal;

import java.io.PrintStream;
import java.io.PrintWriter;

abstract class zzdvm {
    private static Throwable[] zzmai = new Throwable[0];

    zzdvm() {
    }

    public abstract void zza(Throwable th, PrintStream printStream);

    public abstract void zza(Throwable th, PrintWriter printWriter);
}
