package com.google.android.gms.internal;

import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;

public interface zzbee {
    PendingResult<Status> zza(zzbeh com_google_android_gms_internal_zzbeh);
}
