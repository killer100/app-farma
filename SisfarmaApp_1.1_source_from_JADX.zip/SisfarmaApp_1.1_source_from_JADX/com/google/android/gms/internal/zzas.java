package com.google.android.gms.internal;

public interface zzas {
    String zzg(String str);
}
