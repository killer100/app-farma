package com.google.android.gms.internal;

final class zzfgp extends zzfgm {
    private zzfgp() {
        super();
    }
}
