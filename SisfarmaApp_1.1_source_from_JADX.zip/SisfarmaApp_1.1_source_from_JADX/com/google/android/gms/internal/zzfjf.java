package com.google.android.gms.internal;

import java.io.IOException;

enum zzfjf extends zzfje {
    zzfjf(String str, int i) {
        super(str, 0);
    }

    final Object zza(zzffb com_google_android_gms_internal_zzffb) throws IOException {
        return com_google_android_gms_internal_zzffb.readString();
    }
}
