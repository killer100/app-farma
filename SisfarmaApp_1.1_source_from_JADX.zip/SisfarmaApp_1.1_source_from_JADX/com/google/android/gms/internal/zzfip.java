package com.google.android.gms.internal;

final class zzfip extends zzfin<zzfio, zzfio> {
    zzfip() {
    }

    final /* synthetic */ void zzb(Object obj, zzfji com_google_android_gms_internal_zzfji) {
        ((zzfio) obj).zza(com_google_android_gms_internal_zzfji);
    }

    final /* synthetic */ Object zzcq(Object obj) {
        return ((zzffu) obj).zzpgr;
    }

    final /* synthetic */ int zzcr(Object obj) {
        return ((zzfio) obj).zzczw();
    }
}
