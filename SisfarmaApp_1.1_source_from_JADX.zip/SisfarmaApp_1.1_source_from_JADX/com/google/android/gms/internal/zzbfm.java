package com.google.android.gms.internal;

public abstract class zzbfm implements zzbfq {
    public final int describeContents() {
        return 0;
    }
}
