package com.google.android.gms.internal;

import android.content.SharedPreferences;

final class zzcum extends zzcui<Long> {
    public final /* synthetic */ Object zzb(SharedPreferences sharedPreferences) {
        throw new NoSuchMethodError();
    }

    public final /* synthetic */ Object zzkt(String str) {
        throw new NoSuchMethodError();
    }
}
