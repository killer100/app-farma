package com.google.android.gms.internal;

final /* synthetic */ class zzcuk implements zzcuo {
    private final zzcui zzjxf;

    zzcuk(zzcui com_google_android_gms_internal_zzcui) {
        this.zzjxf = com_google_android_gms_internal_zzcui;
    }

    public final Object zzbct() {
        return this.zzjxf.zzbcs();
    }
}
