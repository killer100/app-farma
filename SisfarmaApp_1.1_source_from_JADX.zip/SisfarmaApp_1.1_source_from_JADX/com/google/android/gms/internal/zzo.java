package com.google.android.gms.internal;

public class zzo extends zzad {
    public zzo(Throwable th) {
        super(th);
    }
}
