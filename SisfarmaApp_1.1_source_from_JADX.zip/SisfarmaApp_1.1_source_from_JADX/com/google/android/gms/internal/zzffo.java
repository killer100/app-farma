package com.google.android.gms.internal;

import com.google.android.gms.internal.zzffu.zzd;

final class zzffo extends zzffn<Object> {
    zzffo() {
    }

    final zzffq<Object> zzcn(Object obj) {
        return ((zzd) obj).zzpgz;
    }

    final boolean zzh(Class<?> cls) {
        return zzd.class.isAssignableFrom(cls);
    }
}
