package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.internal.zzan;

public interface zzcxl extends IInterface {
    void zza(zzan com_google_android_gms_common_internal_zzan, int i, boolean z) throws RemoteException;

    void zza(zzcxo com_google_android_gms_internal_zzcxo, zzcxj com_google_android_gms_internal_zzcxj) throws RemoteException;

    void zzeh(int i) throws RemoteException;
}
