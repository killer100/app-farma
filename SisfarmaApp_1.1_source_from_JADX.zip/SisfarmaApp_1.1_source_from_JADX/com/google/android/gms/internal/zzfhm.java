package com.google.android.gms.internal;

public final class zzfhm {
    public static final int zzpiy = 1;
    public static final int zzpiz = 2;
    private static final /* synthetic */ int[] zzpja = new int[]{zzpiy, zzpiz};
}
