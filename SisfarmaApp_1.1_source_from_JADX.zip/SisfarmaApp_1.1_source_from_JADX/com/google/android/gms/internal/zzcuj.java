package com.google.android.gms.internal;

final /* synthetic */ class zzcuj implements zzcuo {
    private final zzcui zzjxf;
    private final zzctv zzjxg;

    zzcuj(zzcui com_google_android_gms_internal_zzcui, zzctv com_google_android_gms_internal_zzctv) {
        this.zzjxf = com_google_android_gms_internal_zzcui;
        this.zzjxg = com_google_android_gms_internal_zzctv;
    }

    public final Object zzbct() {
        return (String) this.zzjxg.zzbcm().get(this.zzjxf.zzjxb);
    }
}
