package com.google.android.gms.internal;

interface zzfhv<T> {
    void zza(T t, zzfji com_google_android_gms_internal_zzfji);

    int zzcp(T t);
}
