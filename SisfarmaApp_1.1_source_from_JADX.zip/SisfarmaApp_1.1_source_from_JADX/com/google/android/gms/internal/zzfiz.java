package com.google.android.gms.internal;

enum zzfiz extends zzfiy {
    zzfiz(String str, int i, zzfjd com_google_android_gms_internal_zzfjd, int i2) {
        super(str, 8, com_google_android_gms_internal_zzfjd, 2);
    }
}
