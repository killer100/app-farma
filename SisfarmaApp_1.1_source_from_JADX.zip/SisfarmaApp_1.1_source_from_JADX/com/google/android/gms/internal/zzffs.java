package com.google.android.gms.internal;

public interface zzffs<T extends zzffs<T>> extends Comparable<T> {
    zzfiy zzcxh();

    zzfjd zzcxi();

    boolean zzcxj();

    boolean zzcxk();

    int zzhq();
}
