package com.google.android.gms.internal;

final class zzfiv extends IllegalArgumentException {
    zzfiv(int i, int i2) {
        super("Unpaired surrogate at index " + i + " of " + i2);
    }
}
