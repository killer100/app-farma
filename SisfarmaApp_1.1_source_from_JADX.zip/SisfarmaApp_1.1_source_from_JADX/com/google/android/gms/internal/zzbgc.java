package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzbgc extends IInterface {
    void zzci(int i) throws RemoteException;
}
