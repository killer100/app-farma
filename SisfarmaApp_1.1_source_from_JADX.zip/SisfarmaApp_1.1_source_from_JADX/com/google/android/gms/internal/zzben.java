package com.google.android.gms.internal;

import com.google.android.gms.common.api.Status;

final class zzben extends zzbel {
    private /* synthetic */ zzbem zzfkg;

    zzben(zzbem com_google_android_gms_internal_zzbem) {
        this.zzfkg = com_google_android_gms_internal_zzbem;
        super();
    }

    public final void zzo(Status status) {
        this.zzfkg.setResult(status);
    }
}
