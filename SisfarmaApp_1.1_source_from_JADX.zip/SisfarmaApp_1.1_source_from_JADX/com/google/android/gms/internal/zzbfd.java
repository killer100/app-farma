package com.google.android.gms.internal;

final class zzbfd extends zzbey<String> {
    zzbfd(String str, String str2) {
        super(str, str2);
    }
}
