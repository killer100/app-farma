package com.google.android.gms.internal;

import java.util.Arrays;

final class zzfeu implements zzfew {
    private zzfeu() {
    }

    public final byte[] zzf(byte[] bArr, int i, int i2) {
        return Arrays.copyOfRange(bArr, i, i + i2);
    }
}
