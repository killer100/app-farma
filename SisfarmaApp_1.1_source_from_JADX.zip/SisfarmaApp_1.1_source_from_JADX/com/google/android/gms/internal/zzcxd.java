package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.zze;
import com.google.android.gms.common.internal.zzan;

public interface zzcxd extends zze {
    void connect();

    void zza(zzan com_google_android_gms_common_internal_zzan, boolean z);

    void zza(zzcxj com_google_android_gms_internal_zzcxj);

    void zzbdb();
}
