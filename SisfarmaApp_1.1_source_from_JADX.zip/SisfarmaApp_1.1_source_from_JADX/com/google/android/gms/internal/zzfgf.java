package com.google.android.gms.internal;

public final class zzfgf extends zzfge {
    public zzfgf(String str) {
        super(str);
    }
}
