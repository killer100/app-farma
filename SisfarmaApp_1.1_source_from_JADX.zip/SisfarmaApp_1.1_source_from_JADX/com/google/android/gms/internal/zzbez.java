package com.google.android.gms.internal;

final class zzbez extends zzbey<Boolean> {
    zzbez(String str, Boolean bool) {
        super(str, bool);
    }
}
