package com.google.android.gms.internal;

final class zzbfc extends zzbey<Float> {
    zzbfc(String str, Float f) {
        super(str, f);
    }
}
