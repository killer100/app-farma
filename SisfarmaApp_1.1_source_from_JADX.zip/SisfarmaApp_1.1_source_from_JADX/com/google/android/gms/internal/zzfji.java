package com.google.android.gms.internal;

interface zzfji {
    void zzb(int i, Object obj);

    int zzcwv();
}
