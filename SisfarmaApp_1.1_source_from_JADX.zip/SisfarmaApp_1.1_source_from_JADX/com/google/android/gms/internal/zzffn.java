package com.google.android.gms.internal;

abstract class zzffn<T extends zzffs<T>> {
    zzffn() {
    }

    abstract zzffq<T> zzcn(Object obj);

    abstract boolean zzh(Class<?> cls);
}
