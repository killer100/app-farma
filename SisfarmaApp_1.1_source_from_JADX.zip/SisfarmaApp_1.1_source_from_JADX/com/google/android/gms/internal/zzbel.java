package com.google.android.gms.internal;

import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;

class zzbel extends zzber {
    private zzbel() {
    }

    public final void zza(Status status, long j) {
        throw new UnsupportedOperationException();
    }

    public final void zza(Status status, zzbef com_google_android_gms_internal_zzbef) {
        throw new UnsupportedOperationException();
    }

    public final void zza(Status status, zzbeh[] com_google_android_gms_internal_zzbehArr) {
        throw new UnsupportedOperationException();
    }

    public final void zza(DataHolder dataHolder) {
        throw new UnsupportedOperationException();
    }

    public final void zzb(Status status, long j) {
        throw new UnsupportedOperationException();
    }

    public final void zzb(Status status, zzbef com_google_android_gms_internal_zzbef) {
        throw new UnsupportedOperationException();
    }

    public void zzo(Status status) {
        throw new UnsupportedOperationException();
    }

    public final void zzp(Status status) {
        throw new UnsupportedOperationException();
    }

    public final void zzq(Status status) {
        throw new UnsupportedOperationException();
    }
}
