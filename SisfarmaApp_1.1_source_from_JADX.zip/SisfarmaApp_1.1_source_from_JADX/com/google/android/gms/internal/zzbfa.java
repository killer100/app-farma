package com.google.android.gms.internal;

final class zzbfa extends zzbey<Long> {
    zzbfa(String str, Long l) {
        super(str, l);
    }
}
