package com.google.android.gms.internal;

abstract class zzfey extends zzfes {
    zzfey() {
    }

    abstract boolean zza(zzfes com_google_android_gms_internal_zzfes, int i, int i2);

    protected final int zzcvn() {
        return 0;
    }

    protected final boolean zzcvo() {
        return true;
    }
}
