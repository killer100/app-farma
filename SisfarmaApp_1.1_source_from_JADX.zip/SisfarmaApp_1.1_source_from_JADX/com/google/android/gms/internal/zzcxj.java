package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzcxj extends IInterface {
    void zzb(zzcxq com_google_android_gms_internal_zzcxq) throws RemoteException;
}
