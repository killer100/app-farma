package com.google.android.gms.internal;

import java.io.IOException;

public final class zzfjv {
    public static final String[] EMPTY_STRING_ARRAY = new String[0];
    private static int zzpnl = 11;
    private static int zzpnm = 12;
    private static int zzpnn = 16;
    private static int zzpno = 26;
    public static final int[] zzpnp = new int[0];
    public static final long[] zzpnq = new long[0];
    public static final float[] zzpnr = new float[0];
    public static final double[] zzpns = new double[0];
    public static final boolean[] zzpnt = new boolean[0];
    public static final byte[][] zzpnu = new byte[0][];
    public static final byte[] zzpnv = new byte[0];

    public static final int zzb(zzfjj com_google_android_gms_internal_zzfjj, int i) throws IOException {
        int i2 = 1;
        int position = com_google_android_gms_internal_zzfjj.getPosition();
        com_google_android_gms_internal_zzfjj.zzkq(i);
        while (com_google_android_gms_internal_zzfjj.zzcvt() == i) {
            com_google_android_gms_internal_zzfjj.zzkq(i);
            i2++;
        }
        com_google_android_gms_internal_zzfjj.zzam(position, i);
        return i2;
    }
}
