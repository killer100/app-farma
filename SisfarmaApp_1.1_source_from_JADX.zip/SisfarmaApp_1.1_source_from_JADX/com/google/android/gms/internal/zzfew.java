package com.google.android.gms.internal;

interface zzfew {
    byte[] zzf(byte[] bArr, int i, int i2);
}
