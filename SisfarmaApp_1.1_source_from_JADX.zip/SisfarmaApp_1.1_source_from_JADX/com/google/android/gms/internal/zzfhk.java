package com.google.android.gms.internal;

public interface zzfhk<MessageType> {
    MessageType zzc(zzffb com_google_android_gms_internal_zzffb, zzffm com_google_android_gms_internal_zzffm) throws zzfge;

    MessageType zze(zzffb com_google_android_gms_internal_zzffb, zzffm com_google_android_gms_internal_zzffm) throws zzfge;
}
