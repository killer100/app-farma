package com.google.android.gms.internal;

final class zzbev {
    public final String zzfkl;
    public final long zzfkm;
    public final long zzfkn;

    public zzbev(String str, long j, long j2) {
        this.zzfkl = str;
        this.zzfkm = j;
        this.zzfkn = j2;
    }
}
