package com.google.android.gms.internal;

public interface zzy<T> {
    void zzb(T t);
}
