package com.google.android.gms.internal;

import android.support.v4.content.WakefulBroadcastReceiver;

public abstract class zzcxs extends WakefulBroadcastReceiver {
    private static String TAG = "GCoreWakefulBroadcastReceiver";
}
