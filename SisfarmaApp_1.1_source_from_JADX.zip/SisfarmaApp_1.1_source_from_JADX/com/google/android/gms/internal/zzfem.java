package com.google.android.gms.internal;

public abstract class zzfem implements zzfhe, Cloneable {
    private boolean zzpfc = true;
    private int zzpfd = -1;

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        throw new UnsupportedOperationException("clone() should be implemented by subclasses.");
    }
}
