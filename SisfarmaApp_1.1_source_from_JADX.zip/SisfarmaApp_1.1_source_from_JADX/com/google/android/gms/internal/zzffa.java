package com.google.android.gms.internal;

final class zzffa implements zzfew {
    private zzffa() {
    }

    public final byte[] zzf(byte[] bArr, int i, int i2) {
        Object obj = new byte[i2];
        System.arraycopy(bArr, i, obj, 0, i2);
        return obj;
    }
}
