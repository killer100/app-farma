package com.google.android.gms.internal;

public final class zzg extends zzab {
    public zzg(zzp com_google_android_gms_internal_zzp) {
        super(com_google_android_gms_internal_zzp);
    }
}
