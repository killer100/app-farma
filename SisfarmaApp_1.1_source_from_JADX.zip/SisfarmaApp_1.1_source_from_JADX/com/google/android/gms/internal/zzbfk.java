package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.net.Uri;
import android.widget.ImageView;

public final class zzbfk extends ImageView {
    public static int zzakg() {
        throw new NoSuchMethodError();
    }

    public static void zzcd(int i) {
        throw new NoSuchMethodError();
    }

    public static void zzn(Uri uri) {
        throw new NoSuchMethodError();
    }

    protected final void onDraw(Canvas canvas) {
        throw new NoSuchMethodError();
    }

    protected final void onMeasure(int i, int i2) {
        throw new NoSuchMethodError();
    }
}
