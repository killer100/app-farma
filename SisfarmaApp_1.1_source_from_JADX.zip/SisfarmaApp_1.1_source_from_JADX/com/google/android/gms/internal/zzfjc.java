package com.google.android.gms.internal;

enum zzfjc extends zzfiy {
    zzfjc(String str, int i, zzfjd com_google_android_gms_internal_zzfjd, int i2) {
        super(str, 11, com_google_android_gms_internal_zzfjd, 2);
    }
}
