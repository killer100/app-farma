package com.google.android.gms.internal;

import java.util.Iterator;

final class zzfia {
    private static final Iterator<Object> zzpke = new zzfib();
    private static final Iterable<Object> zzpkf = new zzfic();

    static <T> Iterable<T> zzczn() {
        return zzpkf;
    }
}
