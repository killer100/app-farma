package com.google.android.gms.internal;

public final class zzcuh {
    static boolean equals(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }
}
