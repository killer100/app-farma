package com.google.android.gms.internal;

import java.io.IOException;

public interface zzfhf extends zzfhg, Cloneable {
    zzfhf zzb(zzffb com_google_android_gms_internal_zzffb, zzffm com_google_android_gms_internal_zzffm) throws IOException;

    zzfhe zzcxu();

    zzfhe zzcxv();

    zzfhf zzd(zzfhe com_google_android_gms_internal_zzfhe);
}
