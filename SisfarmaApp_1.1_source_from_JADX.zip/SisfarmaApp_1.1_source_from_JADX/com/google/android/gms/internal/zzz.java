package com.google.android.gms.internal;

public interface zzz {
    void zza(zzr<?> com_google_android_gms_internal_zzr_, zzad com_google_android_gms_internal_zzad);

    void zza(zzr<?> com_google_android_gms_internal_zzr_, zzw<?> com_google_android_gms_internal_zzw_, Runnable runnable);

    void zzb(zzr<?> com_google_android_gms_internal_zzr_, zzw<?> com_google_android_gms_internal_zzw_);
}
