package com.google.android.gms.internal;

public enum zzfjd {
    INT(Integer.valueOf(0)),
    LONG(Long.valueOf(0)),
    FLOAT(Float.valueOf(0.0f)),
    DOUBLE(Double.valueOf(0.0d)),
    BOOLEAN(Boolean.valueOf(false)),
    STRING(""),
    BYTE_STRING(zzfes.zzpfg),
    ENUM(null),
    MESSAGE(null);
    
    private final Object zzpmt;

    private zzfjd(Object obj) {
        this.zzpmt = obj;
    }
}
