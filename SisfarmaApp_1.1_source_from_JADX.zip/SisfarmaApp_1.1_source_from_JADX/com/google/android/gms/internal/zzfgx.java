package com.google.android.gms.internal;

final class zzfgx<K, V> {
    public final V zzjxd;
    public final zzfiy zzpio;
    public final K zzpip;
    public final zzfiy zzpiq;

    public zzfgx(zzfiy com_google_android_gms_internal_zzfiy, K k, zzfiy com_google_android_gms_internal_zzfiy2, V v) {
        this.zzpio = com_google_android_gms_internal_zzfiy;
        this.zzpip = k;
        this.zzpiq = com_google_android_gms_internal_zzfiy2;
        this.zzjxd = v;
    }
}
