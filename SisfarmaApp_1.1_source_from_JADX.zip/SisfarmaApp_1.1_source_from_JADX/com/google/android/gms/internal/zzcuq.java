package com.google.android.gms.internal;

import android.os.IInterface;

public interface zzcuq extends IInterface {
}
