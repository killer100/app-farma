package com.google.android.gms.internal;

public interface zzfhg {
    boolean isInitialized();

    zzfhe zzcxq();
}
