package com.google.android.gms.internal;

final /* synthetic */ class zzcul implements zzcuo {
    private final String zzdec;
    private final boolean zzjxh = false;

    zzcul(String str, boolean z) {
        this.zzdec = str;
    }

    public final Object zzbct() {
        return Boolean.valueOf(zzdmf.zza(zzcui.zzair.getContentResolver(), this.zzdec, this.zzjxh));
    }
}
