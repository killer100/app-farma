package com.google.android.gms.internal;

public final class zzfgg extends zzfgk {
    public static zzfhe zzcyj() {
        throw new NoSuchMethodError();
    }

    public final boolean equals(Object obj) {
        throw new NoSuchMethodError();
    }

    public final int hashCode() {
        throw new NoSuchMethodError();
    }

    public final String toString() {
        throw new NoSuchMethodError();
    }
}
