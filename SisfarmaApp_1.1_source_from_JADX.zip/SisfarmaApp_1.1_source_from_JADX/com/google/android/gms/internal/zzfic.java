package com.google.android.gms.internal;

import java.util.Iterator;

final class zzfic implements Iterable<Object> {
    zzfic() {
    }

    public final Iterator<Object> iterator() {
        return zzfia.zzpke;
    }
}
