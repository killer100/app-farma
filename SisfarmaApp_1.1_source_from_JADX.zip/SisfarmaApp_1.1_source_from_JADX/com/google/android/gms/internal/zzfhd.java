package com.google.android.gms.internal;

interface zzfhd {
    boolean zzi(Class<?> cls);

    zzfhc zzj(Class<?> cls);
}
