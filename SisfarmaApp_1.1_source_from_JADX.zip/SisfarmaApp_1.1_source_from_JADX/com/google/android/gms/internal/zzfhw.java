package com.google.android.gms.internal;

interface zzfhw {
    <T> zzfhv<T> zzk(Class<T> cls);
}
