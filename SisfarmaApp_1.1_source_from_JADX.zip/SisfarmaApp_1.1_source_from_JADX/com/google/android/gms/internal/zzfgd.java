package com.google.android.gms.internal;

import java.util.List;
import java.util.RandomAccess;

public interface zzfgd<E> extends List<E>, RandomAccess {
    void zzbiy();

    boolean zzcvi();

    zzfgd<E> zzly(int i);
}
