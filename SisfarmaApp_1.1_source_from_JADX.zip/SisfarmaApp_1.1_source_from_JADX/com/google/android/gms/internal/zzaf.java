package com.google.android.gms.internal;

final class zzaf {
    public final String name;
    public final long time;
    public final long zzbo;

    public zzaf(String str, long j, long j2) {
        this.name = str;
        this.zzbo = j;
        this.time = j2;
    }
}
