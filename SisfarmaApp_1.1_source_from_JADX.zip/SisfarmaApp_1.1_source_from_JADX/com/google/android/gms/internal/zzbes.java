package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzbes extends IInterface {
    void zza(zzbeq com_google_android_gms_internal_zzbeq, zzbeh com_google_android_gms_internal_zzbeh) throws RemoteException;
}
