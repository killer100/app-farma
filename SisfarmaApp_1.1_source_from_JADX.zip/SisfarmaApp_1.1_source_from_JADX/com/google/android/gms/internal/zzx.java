package com.google.android.gms.internal;

public interface zzx {
    void zzd(zzad com_google_android_gms_internal_zzad);
}
