package com.google.android.gms.internal;

final class zzfhp implements zzfhc {
    public final int zzcyv() {
        throw new NoSuchMethodError();
    }

    public final boolean zzcyw() {
        throw new NoSuchMethodError();
    }

    public final zzfhe zzcyx() {
        throw new NoSuchMethodError();
    }

    public final boolean zzcyy() {
        throw new NoSuchMethodError();
    }
}
